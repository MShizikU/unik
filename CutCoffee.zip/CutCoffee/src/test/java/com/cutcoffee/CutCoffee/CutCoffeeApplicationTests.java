package com.cutcoffee.CutCoffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CutCoffeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
