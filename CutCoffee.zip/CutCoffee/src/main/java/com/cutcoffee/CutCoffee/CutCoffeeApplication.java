package com.cutcoffee.CutCoffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CutCoffeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CutCoffeeApplication.class, args);
	}

}
