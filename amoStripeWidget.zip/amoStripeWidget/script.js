define(['jquery', 'lib/components/base/modal'], function($, Modal) {
  var CustomWidget = function() {

      var self = this, // для доступа к объекту из методов
          system = self.system, //Данный метод возвращает объект с переменными системы.
          langs = self.langs, //Объект локализации с данными из файла локализации (папки i18n)
          payment = {
              number: '',
              percent: '',
              summ: '',
              date: '',
              comment: '',
              paid: '0',
              budget: $('.card-budget__input [name="lead[PRICE]"]').val(), //AMOCRM.constant('card_element').raw_price,
              payment_item: function() {
                  return '<div class = "payment-item">' +
                      '<div class = "number">' + this.number + '</div>' +
                      '<div class = "percent"><input type = "text" name = "percent" value="' + this.percent + '"></div>' +
                      '<div class = "summ"><input type = "text" name = "summ" value = "' + this.summ + '"></div>' +
                      '<div class = "date"><input type="text" name = "date" class="datepicker-here" value = "' + this.date + '"></div>' +
                      '<div class = "comment"><input type = "text" name = "comment" value = "' + this.comment + '"></div>' +
                      '<div class = "paid"><input type = "checkbox" name = "paid" ' + ((this.paid == '1') ? "checked" : "") + '></div>' +
                      '<div class = "close">&#10006;</div>' +
                      '</div>';
              },
              paymant_isjson: function(text) {
                  if (typeof text !== "string") {
                      return false;
                  }
                  try {
                      JSON.parse(text);
                      return true;
                  } catch (error) {
                      return false;
                  }
              }
          };
      this.callbacks = {
          settings: function() {

          },
          init: function() {
              console.log(self.system().area);
              if (self.system().area == 'lcard'||self.system().area == 'outer_space') {
                  payment['paymentAdd']=function(){
                      $('div[data-id="leads_89051569315416"] .linked-form__field').hide();
                      var payment_block =
                          '<div class = "payment-block">' +
                          '<div class = "payment-list-block">' +
                          '<div class = "payment-title">' +
                          '<div class = "number">№</div>' +
                          '<div class = "percent">%</div>' +
                          '<div class = "summ">Сумма</div>' +
                          '<div class = "date">Дата</div>' +
                          '<div class = "comment">Комментарий</div>' +
                          '<div class = "paid">Опл.</div>' +
                          '<div class = "close"></div>' +
                          '</div>' +
                          '<div class = "payment-list">' +
                          '</div>' +
                          '<div class = "payment-control">Новый платеж</div>' +
                          '</div>' +
                          '</div>';
                      $('div.linked-forms__group-wrapper[data-id="leads_89051569315416"]').prepend(payment_block);
                      let payment_json = $('textarea[name="CFV[480245]"]').val();
                      if (!payment.paymant_isjson(payment_json)) payment_json = '{}';
                      let payment_mass = JSON.parse(payment_json);
                      for (var key in payment_mass) {
                          let payment_one = payment;
                          payment_one.number = parseInt(key) + 1;
                          payment_one.percent = payment_mass[key]['percent'];
                          payment_one.summ = payment_mass[key]['summ'];
                          payment_one.date = payment_mass[key]['date'];
                          payment_one.date = payment_one.date.replace('d', '').trim();
                          payment_one.comment = payment_mass[key]['comment'];
                          payment_one.paid = payment_mass[key]['paid'];
                          payment_one.paid = payment_one.paid.replace('st', '').trim();
                          $('.payment-block .payment-list').append(payment_one.payment_item());
                      }
                      $('.datepicker-here').datepicker();
                  }
                  payment.paymentAdd();
                  if($('.ig-calculation').length == 0){
                      console.log($('.ig-calculation').length);
                      $('div#4407').after('<div class = "ig-calculation"><button>В бюджет</button></div>');
                      payment.addSumm();
                  }

                  var service_block = '<div class = "service-block"><div class = "service-title">Услуги</div><div class = "service-block-list"></div></div>';
                  $('div.linked-forms__group-wrapper[data-id="leads_89051569315416"]').append(service_block);
                  payment.service_item();
              }
              return true;
          },
          bind_actions: function() {
              if (self.system().area == 'lcard'||self.system().area == 'outer_space') {
                  $('.payment-block .payment-control').click(function() {
                      let payment_one = payment;
                      let number = 0;
                      $('.payment-block .payment-list .payment-item').each(function(index) {
                          number = index + 1;
                          $(this).find('.number').text(number);
                      });
                      number++;
                      payment_one.number = number;
                      payment_one.percent = '100';
                      payment_one.budget = $('.card-budget__input [name="lead[PRICE]"]').val();
                      payment_one.summ = payment_one.budget;
                      payment_one.date = '';
                      payment_one.comment = '';
                      payment_one.paid = '0';
                      $('.payment-block .payment-list').append(payment_one.payment_item());
                      $('.payment-block .payment-item:last-child .datepicker-here').datepicker();
                      payment.payment_save();
                  });
                  $('.payment-block').on('click', '.close', function() {
                      $(this).parent().remove();
                      $('.payment-block .payment-list .payment-item').each(function(index) {
                          number = index + 1;
                          $(this).find('.numder').text(number);
                      });
                      payment.payment_save();
                  });
                  $('.payment-block').on('input change', '.payment-item input', function() {
                      payment.budget = $('.card-budget__input [name="lead[PRICE]"]').val();
                      let summ = parseInt($(this).val());
                      let budget = parseInt(payment.budget);
                      if ($(this).parent().hasClass('summ')) {
                          if (budget > 0) $(this).parent().parent().find('.percent input').val(Math.round(summ * 100 / budget));
                      }
                      if ($(this).parent().hasClass('percent')) {
                          if (budget > 0) $(this).parent().parent().find('.summ input').val(Math.round(budget * summ / 100));
                      }
                      payment.payment_save();
                  });
                  $('div[data-id="4407"]').click(function() {
                      if ($('.ig-calculation').length == 0) {
                          $('div#4407').after('<div class = "ig-calculation"><button>В бюджет</button></div>');
                          payment.addSumm();
                      }
                  });

              }

              return true;
          },
          render: function() {
              var lang = self.i18n('userLang');
              w_code = self.get_settings().widget_code;
              if (typeof(AMOCRM.data.current_card) != 'undefined') {
                  if (AMOCRM.data.current_card.id == 0) {
                      return false;
                  }
              }
              $('body').append('<link type="text/css" rel="stylesheet" href="/upl/' + w_code + '/widget/style.css?' + (new Date()).getTime() + '" >');
              $('body').append('<link type="text/css" rel="stylesheet" href="/upl/' + w_code + '/widget/datepicker.min.css?' + (new Date()).getTime() + '" >');
              $('body').append('<script src="/upl/' + w_code + '/widget/datepicker.min.js?' + (new Date()).getTime() + '"></script> ');
              return true;
          },
          contacts: {
              selected: function() {}
          },
          leads: {
              selected: function() {

              }
          },
          onSave: function() {

              return true;
          }
      };
      return this;
  };
  return CustomWidget;
});
